import 'package:flutter/material.dart';
import 'package:gogame/viewmodels/base_model.dart';

class SplashViewModel extends BaseModel {


  SplashViewModel(BuildContext newContext) {
    context = newContext;
  }



}
