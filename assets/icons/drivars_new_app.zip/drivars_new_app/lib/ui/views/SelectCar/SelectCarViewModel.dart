import 'package:flutter/cupertino.dart';
import 'package:gogame/constants/API.dart';
import 'package:gogame/constants/languageContstants.dart';
import 'package:gogame/models/api/dashboard.dart';
import 'package:gogame/models/api/profile.dart';
import 'package:gogame/models/user_provider.dart';
import 'package:gogame/services/api_service.dart';
import 'package:gogame/ui/shared/shared_preference.dart';

import 'package:gogame/viewmodels/base_model.dart';
import 'package:provider/provider.dart';

import '../../../utils.dart';

class  SelectCarViewModel extends BaseModel {
 // SelectCar selectCar;

  SelectCarViewModel(BuildContext newContext) {
    context = newContext;
  }




}
