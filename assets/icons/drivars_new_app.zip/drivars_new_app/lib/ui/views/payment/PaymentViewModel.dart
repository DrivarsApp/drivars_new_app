import 'package:flutter/material.dart';

import 'package:gogame/viewmodels/base_model.dart';

class PaymentViewModel extends BaseModel {
  PaymentViewModel(BuildContext newContext) {
    context = newContext;
  }

  void init() {}
}
