import 'package:flutter/material.dart';
import 'package:gogame/viewmodels/base_model.dart';

class PermissionViewModel extends BaseModel {


  PermissionViewModel(BuildContext newContext) {
    context = newContext;
  }


}
