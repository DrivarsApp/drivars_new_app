import 'package:flutter/material.dart';

import 'package:gogame/viewmodels/base_model.dart';

class ReferViewModel extends BaseModel {
  ReferViewModel(BuildContext newContext) {
    context = newContext;
  }
}
