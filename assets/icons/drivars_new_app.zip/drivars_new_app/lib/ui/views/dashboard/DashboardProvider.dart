import 'package:flutter/cupertino.dart';

class DashboardProvider extends ChangeNotifier {}
