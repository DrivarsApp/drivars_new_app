class LocalizationLanguage {
  final String name;
  final String shortName;
  //final Map<String, String> values;
  final String flagId;

  LocalizationLanguage({this.name, this.shortName, this.flagId});
}
