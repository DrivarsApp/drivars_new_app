
class UserDetails {
    String userName;
    String phoneNumber;
    String accessID;
    String userId;


    UserDetails({
      this.userName,
      this.phoneNumber,
      this.userId,this.accessID
});

}
