package com.example.drivars_new_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
